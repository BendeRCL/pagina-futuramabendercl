require("dotenv").config();

const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
const PORT = process.env.PORT || 3000;

// En producción, FRONTEND_URL debe contener el origen de GitHub Pages.
// Durante el desarrollo también se permite localhost.
const origenesPermitidos = [
  process.env.FRONTEND_URL,
  "http://127.0.0.1:5500",
  "http://localhost:5500",
  "http://127.0.0.1:5501",
  "http://localhost:5501",
  "http://127.0.0.1:5502",
  "http://localhost:5502",
  "http://127.0.0.1:3000",
  "http://localhost:3000"
].filter(Boolean);

app.use(cors({
  origin: true,
  credentials: true
}));

const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_DATABASE,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl: process.env.DB_SSL === "true" ? { rejectUnauthorized: false } : false
});

app.get("/", (req, res) => {
  res.send("Backend de consulta funcionando.");
});

// Consulta de personajes desde PostgreSQL mediante INNER JOIN con especies
app.get("/api/personajes", async (req, res) => {
  try {
    const consulta = `
      SELECT
          p.personaje_id AS id,
          p.nombre,
          p.ocupacion,
          p.descripcion,
          p.imagen AS image,
          e.nombre AS especie
      FROM personajes AS p
      INNER JOIN especies AS e
          ON p.especie_id = e.especie_id
      ORDER BY p.personaje_id;
    `;
    const resultado = await pool.query(consulta);
    res.json(resultado.rows);
  } catch (error) {
    console.error("Error al consultar personajes:", error.message);
    res.status(500).json({ mensaje: "Error al consultar la base de datos PostgreSQL." });
  }
});

// Consulta dos tablas relacionadas mediante INNER JOIN.
// Los filtros se aplican en JavaScript en el navegador para mantener simple el ejemplo.
app.get("/api/productos", async (req, res) => {
  try {
  const consulta = `
    SELECT
        p.producto_id,
        p.nombre,
        p.descripcion,
        p.precio,
        c.nombre AS categoria
    FROM demo_productos AS p
    INNER JOIN demo_categorias AS c
        ON p.categoria_id = c.categoria_id
    ORDER BY p.nombre;
`;

    const resultado = await pool.query(consulta);
    res.json(resultado.rows);
  } catch (error) {
    console.error("Error al consultar productos:", error.message);
    res.status(500).json({ mensaje: "Error al consultar la base de datos." });
  }
});

app.listen(PORT, () => {
  console.log("Servidor escuchando en el puerto " + PORT);
});
